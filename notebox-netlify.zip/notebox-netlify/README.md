# Notebox (Netlify)

Notes ki site. Sab log notes download kar sakte hain. Upload aur delete sirf owner kar sakta hai (password se).

## Netlify par chalane ke steps (GitHub se, sabse aasan)

1. github.com par naya repository banao (jaise `notebox`).
2. Is folder ki saari files us repository mein upload karo (`Add file` > `Upload files`). `public`, `netlify`, `lib`, `test` folders aur `package.json`, `netlify.toml` sab chahiye.
3. netlify.com par login karo > `Add new site` > `Import an existing project` > GitHub chuno > apna `notebox` repo chuno.
4. Build settings jaisi hain waisi rehne do (`netlify.toml` sab bata deti hai). `Deploy` dabao.
5. Site ban jaane ke baad: `Site configuration` > `Environment variables` > `Add a variable`.
   - Key: `ADMIN_PASSWORD`
   - Value: apna mazboot password (yahi owner login ka password hoga)
6. `Deploys` mein jaake `Trigger deploy` > `Deploy site` karo, taaki password kaam kare.
7. Site kholo, neeche `Owner login` dabao, password daalo. Ab upload ka box dikhega.

## Limits

- Ek file maximum 5 MB.
- Allowed types: PDF, Word, PowerPoint, Excel, text, Markdown, CSV, JSON, images, ZIP.
- Password kabhi kisi ko mat batao. Badalna ho to Netlify mein `ADMIN_PASSWORD` badlo aur dobara deploy karo.

## Files kahan rehti hain

Netlify Blobs mein (Netlify ka apna storage). Site dobara deploy karne se notes delete nahi hote.
