import assert from "node:assert/strict";
import { makeHandler } from "../lib/handler.mjs";

process.env.ADMIN_PASSWORD = "secret";

const mem = new Map();
const store = {
  async get(k, o) {
    const v = mem.get(k);
    if (v === undefined) return null;
    return o?.type === "json" ? JSON.parse(v) : v;
  },
  async set(k, v) { mem.set(k, v); },
  async setJSON(k, v) { mem.set(k, JSON.stringify(v)); },
  async delete(k) { mem.delete(k); }
};
const handler = makeHandler(() => store);
const call = (path, init) => handler(new Request("http://localhost" + path, init));
const auth = { Authorization: "Bearer secret" };

const upload = (name, bytes, headers = auth) => {
  const fd = new FormData();
  fd.append("file", new File([bytes], name));
  fd.append("title", "Physics ch.1");
  fd.append("description", "Short notes");
  return call("/api/notes", { method: "POST", headers, body: fd });
};

let r = await call("/api/notes");
assert.equal(r.status, 200);
assert.deepEqual(await r.json(), []);

r = await call("/api/login", { method: "POST", headers: { Authorization: "Bearer nope" } });
assert.equal(r.status, 401);
r = await call("/api/login", { method: "POST", headers: auth });
assert.equal(r.status, 200);

assert.equal((await upload("a.pdf", new Uint8Array([1, 2, 3]), {})).status, 401);
assert.equal((await upload("virus.exe", new Uint8Array([1]))).status, 400);
assert.equal((await upload("page.html", new Uint8Array([1]))).status, 400);
assert.equal((await upload("big.pdf", new Uint8Array(5 * 1024 * 1024 + 1))).status, 413);

r = await upload("My Note.pdf", new Uint8Array([1, 2, 3, 4]));
assert.equal(r.status, 201);
const note = await r.json();
assert.equal(note.title, "Physics ch.1");
assert.equal(note.size, 4);

r = await call("/api/notes");
const list = await r.json();
assert.equal(list.length, 1);
assert.equal(list[0].id, note.id);

r = await call(`/api/notes/${note.id}/download`);
assert.equal(r.status, 200);
assert.match(r.headers.get("content-disposition"), /^attachment; filename="My Note\.pdf"/);
assert.deepEqual(new Uint8Array(await r.arrayBuffer()), new Uint8Array([1, 2, 3, 4]));

assert.equal((await call(`/api/notes/${note.id}`, { method: "DELETE" })).status, 401);
assert.equal((await call(`/api/notes/${note.id}`, { method: "DELETE", headers: auth })).status, 200);
assert.deepEqual(await (await call("/api/notes")).json(), []);
assert.equal((await call(`/api/notes/${note.id}/download`)).status, 404);

console.log("All backend checks passed");
