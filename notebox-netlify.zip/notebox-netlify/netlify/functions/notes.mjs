import { getStore } from "@netlify/blobs";
import { makeHandler } from "../../lib/handler.mjs";

export default makeHandler(() => getStore("notebox"));

export const config = { path: ["/api/login", "/api/notes", "/api/notes/*"] };
